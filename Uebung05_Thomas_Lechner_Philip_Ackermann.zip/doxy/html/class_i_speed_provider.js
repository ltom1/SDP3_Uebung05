var class_i_speed_provider =
[
    [ "SPtr", "class_i_speed_provider.html#a3f40159a2df1f75f219746d1c149e0d7", null ],
    [ "WPtr", "class_i_speed_provider.html#a0f3a9a34b4227445623d9ba51a06129b", null ],
    [ "~ISpeedProvider", "class_i_speed_provider.html#af562586c9261b9a5cc3fc82cdf6a15a3", null ],
    [ "GetCurrentSpeed", "class_i_speed_provider.html#aa5db4ae10a3d1639950ef387919c0dd9", null ]
];