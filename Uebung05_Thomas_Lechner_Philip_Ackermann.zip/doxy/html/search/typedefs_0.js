var searchData=
[
  ['sptr_0',['SPtr',['../class_i_speed_provider.html#a3f40159a2df1f75f219746d1c149e0d7',1,'ISpeedProvider']]]
];
