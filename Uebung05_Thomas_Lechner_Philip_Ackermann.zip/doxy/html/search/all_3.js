var searchData=
[
  ['getcurrentspeed_0',['GetCurrentSpeed',['../class_i_speed_provider.html#aa5db4ae10a3d1639950ef387919c0dd9',1,'ISpeedProvider::GetCurrentSpeed()'],['../class_motor_vehicle.html#adbe04de40da6837c2f2e02b32cf0c501',1,'MotorVehicle::GetCurrentSpeed()']]],
  ['getrevolutions_1',['GetRevolutions',['../class_i_wheel_speed_sensor.html#a668d20e7e34738fb44850bc91a3cba7a',1,'IWheelSpeedSensor::GetRevolutions()'],['../class_wheel_speed_simulator.html#aad909ab4c17d9e5982ec007a8731db92',1,'WheelSpeedSimulator::GetRevolutions()']]]
];
