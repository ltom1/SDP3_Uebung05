var searchData=
[
  ['mdisplay_0',['mDisplay',['../class_display.html#affde9ef42b9ce878c1bbb9eeba181ad3',1,'Display']]]
];
