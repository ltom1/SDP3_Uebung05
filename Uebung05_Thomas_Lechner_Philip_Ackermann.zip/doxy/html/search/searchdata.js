var indexSectionsWithContent =
{
  0: "acdgikmnoprsuvw~",
  1: "acdikmosvw",
  2: "cdgkmnoprsuvw~",
  3: "m",
  4: "suw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs"
};

