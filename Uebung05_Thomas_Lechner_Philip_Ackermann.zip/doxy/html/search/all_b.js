var searchData=
[
  ['speedometer_0',['Speedometer',['../class_speedometer.html',1,'Speedometer'],['../class_speedometer.html#a0f37ea8e7c2cb48435d0e857b4c735bb',1,'Speedometer::Speedometer()']]],
  ['sptr_1',['SPtr',['../class_i_speed_provider.html#a3f40159a2df1f75f219746d1c149e0d7',1,'ISpeedProvider']]]
];
