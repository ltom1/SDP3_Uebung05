var class_vehicle =
[
    [ "Vehicle", "class_vehicle.html#a8b7885b66c0f4f46a50ec71a8570f8b3", null ],
    [ "Notify", "class_vehicle.html#a42321a681a655ca9226d50034ef63b5e", null ],
    [ "Register", "class_vehicle.html#aab132e29d6367fa36f2b6861542347dc", null ]
];