var class_i_vehicle_listener =
[
    [ "UPtr", "class_i_vehicle_listener.html#afd1a43db24be2bfa1d63c2f26dc6c377", null ],
    [ "~IVehicleListener", "class_i_vehicle_listener.html#adc110c79eeee6f55b27d33640b4d960c", null ],
    [ "Update", "class_i_vehicle_listener.html#a0b43441d8eccdc21f62144de0ea8b91a", null ]
];