var class_wheel_speed_simulator =
[
    [ "WheelSpeedSimulator", "class_wheel_speed_simulator.html#ac136ee6e77919f6f594660c5279203a4", null ],
    [ "~WheelSpeedSimulator", "class_wheel_speed_simulator.html#a542ab00e7d3af40b03ac9d591a483648", null ],
    [ "GetRevolutions", "class_wheel_speed_simulator.html#aad909ab4c17d9e5982ec007a8731db92", null ]
];