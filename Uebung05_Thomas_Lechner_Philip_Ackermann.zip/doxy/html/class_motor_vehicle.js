var class_motor_vehicle =
[
    [ "MotorVehicle", "class_motor_vehicle.html#a9c8d48ba2dcb6882847fcc3b303f2d08", null ],
    [ "GetCurrentSpeed", "class_motor_vehicle.html#adbe04de40da6837c2f2e02b32cf0c501", null ],
    [ "Process", "class_motor_vehicle.html#a6a34c57468cabe3f472504541ebf5cce", null ]
];