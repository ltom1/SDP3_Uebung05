var class_speedometer =
[
    [ "Speedometer", "class_speedometer.html#a0f37ea8e7c2cb48435d0e857b4c735bb", null ],
    [ "Update", "class_speedometer.html#af879bc7f1b8ba3a245301496feaf1d33", null ]
];