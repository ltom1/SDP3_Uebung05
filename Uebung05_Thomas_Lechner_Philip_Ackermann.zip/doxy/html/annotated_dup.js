var annotated_dup =
[
    [ "AnalogDisplay", "class_analog_display.html", null ],
    [ "Car", "class_car.html", "class_car" ],
    [ "DataPacket", "struct_data_packet.html", null ],
    [ "DigitalDisplay", "class_digital_display.html", null ],
    [ "Display", "class_display.html", "class_display" ],
    [ "ISpeedProvider", "class_i_speed_provider.html", "class_i_speed_provider" ],
    [ "IVehicleListener", "class_i_vehicle_listener.html", "class_i_vehicle_listener" ],
    [ "IWheelSpeedSensor", "class_i_wheel_speed_sensor.html", "class_i_wheel_speed_sensor" ],
    [ "KilometerCounter", "class_kilometer_counter.html", "class_kilometer_counter" ],
    [ "MotorVehicle", "class_motor_vehicle.html", "class_motor_vehicle" ],
    [ "Object", "class_object.html", "class_object" ],
    [ "Speedometer", "class_speedometer.html", "class_speedometer" ],
    [ "Vehicle", "class_vehicle.html", "class_vehicle" ],
    [ "WheelSpeedSimulator", "class_wheel_speed_simulator.html", "class_wheel_speed_simulator" ],
    [ "WindowsDisplay", "class_windows_display.html", null ]
];