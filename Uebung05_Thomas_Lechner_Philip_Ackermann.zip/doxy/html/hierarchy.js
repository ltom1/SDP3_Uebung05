var hierarchy =
[
    [ "DataPacket", "struct_data_packet.html", null ],
    [ "ISpeedProvider", "class_i_speed_provider.html", [
      [ "MotorVehicle", "class_motor_vehicle.html", [
        [ "Car", "class_car.html", null ]
      ] ]
    ] ],
    [ "IVehicleListener", "class_i_vehicle_listener.html", [
      [ "KilometerCounter", "class_kilometer_counter.html", null ],
      [ "Speedometer", "class_speedometer.html", null ]
    ] ],
    [ "IWheelSpeedSensor", "class_i_wheel_speed_sensor.html", [
      [ "WheelSpeedSimulator", "class_wheel_speed_simulator.html", null ]
    ] ],
    [ "Object", "class_object.html", [
      [ "Display", "class_display.html", [
        [ "KilometerCounter", "class_kilometer_counter.html", null ],
        [ "Speedometer", "class_speedometer.html", null ]
      ] ],
      [ "Vehicle", "class_vehicle.html", [
        [ "MotorVehicle", "class_motor_vehicle.html", null ]
      ] ],
      [ "WheelSpeedSimulator", "class_wheel_speed_simulator.html", null ],
      [ "WindowsDisplay", "class_windows_display.html", [
        [ "AnalogDisplay", "class_analog_display.html", null ],
        [ "DigitalDisplay", "class_digital_display.html", null ]
      ] ]
    ] ]
];