var class_i_wheel_speed_sensor =
[
    [ "UPtr", "class_i_wheel_speed_sensor.html#a64b15dc4e54e8b4e3a51c4c94dfb6495", null ],
    [ "~IWheelSpeedSensor", "class_i_wheel_speed_sensor.html#a4a60b180afb566c3f25600e9cd4c4e81", null ],
    [ "GetRevolutions", "class_i_wheel_speed_sensor.html#a668d20e7e34738fb44850bc91a3cba7a", null ]
];